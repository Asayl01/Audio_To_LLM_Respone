from flask import Flask, render_template, jsonify, request
from flask_cors import CORS
import whisper
import cohere
import base64
import os
import tempfile
import subprocess
from gtts import gTTS

app = Flask(__name__, template_folder='templates', static_folder='static')
CORS(app)

SAMPLE_RATE = 16000
FILENAME_INPUT = "temp_recording.wav"
MODEL_SIZE = "medium"
COHERE_API_KEY = "xx"  # Replace with your real key when testing

print("...جاري تحميل نموذج Whisper...")
whisper_model = whisper.load_model(MODEL_SIZE)
print("✅ نموذج Whisper جاهز.")

if not COHERE_API_KEY or COHERE_API_KEY == "ضع مفتاحك الحقيقي هنا":
    print(⚠️ مفتاح Cohere API مفقود!")
    cohere_client = None
else:
    print("...جاري تهيئة Cohere...")
    cohere_client = cohere.Client(COHERE_API_KEY)
    print("✅ Cohere جاهز.")

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/process-audio', methods=['POST'])
def process_audio():
    if not cohere_client:
        return jsonify({'status': 'error', 'message': 'خدمة المساعد غير مهيأة بسبب عدم وجود مفتاح API.'})

    try:
        audio_data_b64 = request.json['audio_data']
        audio_bytes = base64.b64decode(audio_data_b64)

        with tempfile.NamedTemporaryFile(delete=False, suffix=".webm") as temp_input:
            temp_input.write(audio_bytes)
            temp_input_path = temp_input.name

        converted_wav_path = FILENAME_INPUT
        subprocess.run([
            "ffmpeg", "-y",
            "-i", temp_input_path,
            "-ar", str(SAMPLE_RATE),
            "-ac", "1",
            "-f", "wav",
            converted_wav_path
        ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

        result = whisper_model.transcribe(converted_wav_path, fp16=False, language="ar")
        user_text = result["text"].strip()

        os.remove(temp_input_path)
        os.remove(converted_wav_path)

        if not user_text:
            return jsonify({
                'status': 'success',
                'user_text': '(لم يتم التعرف على كلام)',
                'bot_text': 'عذرًا، لم أسمعك بوضوح. حاول مرة أخرى.'
            })

        response = cohere_client.chat(
            message=user_text,
            model="command-r",
            preamble="أنت مساعد ذكي ومفيد تتحدث اللغة العربية بطلاقة ومختصر في إجاباتك."
        )
        cohere_text = response.text

        tts = gTTS(text=cohere_text, lang='ar')
        tts.save("static/response.mp3")

        return jsonify({
            'status': 'success',
            'user_text': user_text,
            'bot_text': cohere_text
        })

    except Exception as e:
        print(f"❌ خطأ أثناء المعالجة: {e}")
        return jsonify({'status': 'error', 'message': 'حدث خطأ أثناء معالجة الصوت.'})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)
