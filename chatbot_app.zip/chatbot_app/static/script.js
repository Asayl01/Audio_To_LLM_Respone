document.addEventListener('DOMContentLoaded', () => {
  const recordBtn = document.getElementById('record-btn');
  const statusText = document.getElementById('status-text');
  const chatBox = document.getElementById('chat-box');
  let mediaRecorder;
  let audioChunks = [];
  let isRecording = false;

  recordBtn.addEventListener('click', async () => {
    if (!isRecording) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        mediaRecorder = new MediaRecorder(stream);

        mediaRecorder.ondataavailable = event => {
          audioChunks.push(event.data);
        };

        mediaRecorder.onstop = processAudio;

        mediaRecorder.start();
        isRecording = true;
        recordBtn.classList.add('is-recording');
        statusText.textContent = 'جاري الاستماع... انقر للإيقاف';
      } catch (error) {
        console.error("Error accessing microphone:", error);
        statusText.textContent = 'لا يمكن الوصول للميكروفون';
      }
    } else {
      mediaRecorder.stop();
      isRecording = false;
      recordBtn.classList.remove('is-recording');
      statusText.textContent = 'جاري المعالجة...';
    }
  });

  async function processAudio() {
    const audioBlob = new Blob(audioChunks, { type: 'audio/webm' });
    audioChunks = [];

    const reader = new FileReader();
    reader.readAsDataURL(audioBlob);
    reader.onloadend = async () => {
      const base64String = reader.result.split(',')[1];

      try {
        const response = await fetch('http://127.0.0.1:5000/process-audio', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ audio_data: base64String }),
        });

        const data = await response.json();

        if (data.status === 'success') {
          addMessage(data.user_text, 'user');

          setTimeout(() => {
            addMessage(data.bot_text, 'bot');

            // تشغيل الصوت من الرد mp3
            const audio = new Audio('/static/response.mp3');
            audio.play();
          }, 300);
        } else {
          addMessage(data.message, 'bot', true);
        }
      } catch (error) {
        console.error("Error sending audio to server:", error);
        addMessage('لا يمكن الاتصال بالخادم. تأكد من أن الخادم يعمل.', 'bot', true);
      } finally {
        statusText.textContent = 'اضغط للتحدث';
      }
    };
  }

  function addMessage(text, sender, isError = false) {
    const messageContainer = document.createElement('div');
    messageContainer.classList.add('message', `${sender}-message`);

    if (isError) {
      messageContainer.classList.add('error-message');
    }

    if (sender === 'bot') {
      const avatar = document.createElement('img');
      avatar.src = "/static/robot.png";
      avatar.classList.add('avatar');
      messageContainer.appendChild(avatar);
    }

    const p = document.createElement('p');
    p.textContent = text;
    messageContainer.appendChild(p);

    chatBox.appendChild(messageContainer);
    chatBox.scrollTop = chatBox.scrollHeight;
  }
});
